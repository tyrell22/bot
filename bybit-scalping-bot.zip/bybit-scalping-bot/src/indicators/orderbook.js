// Orderbook Analysis
const logger = require('../utils/logger');

class OrderbookAnalysis {
  constructor(config) {
    this.config = config;
    this.depthToAnalyze = config.indicators.orderbook.depth || 10; // Levels to analyze
    this.imbalanceThreshold = config.indicators.orderbook.imbalanceThreshold || 2; // Ratio indicating significant imbalance
  }
  
  // Analyze orderbook for support and resistance levels
  analyzeOrderbook(orderbook) {
    try {
      const { bids, asks } = orderbook;
      
      // Ensure we have data to analyze
      if (!bids || !bids.length || !asks || !asks.length) {
        logger.warn('Orderbook data is empty or invalid');
        return {
          buyPressure: 0,
          sellPressure: 0,
          imbalanceRatio: 1,
          dominantSide: 'neutral',
          supportLevels: [],
          resistanceLevels: [],
          liquidityProfile: 'neutral'
        };
      }
      
      // Calculate buy and sell pressure
      const totalBidVolume = this.calculateTotalVolume(bids, this.depthToAnalyze);
      const totalAskVolume = this.calculateTotalVolume(asks, this.depthToAnalyze);
      
      // Calculate imbalance ratio
      const imbalanceRatio = totalBidVolume / totalAskVolume;
      
      // Determine dominant side
      let dominantSide = 'neutral';
      if (imbalanceRatio >= this.imbalanceThreshold) {
        dominantSide = 'buy';
      } else if (1 / imbalanceRatio >= this.imbalanceThreshold) {
        dominantSide = 'sell';
      }
      
      // Find support levels (significant bid walls)
      const supportLevels = this.findLiquidityLevels(bids, 'support', this.depthToAnalyze);
      
      // Find resistance levels (significant ask walls)
      const resistanceLevels = this.findLiquidityLevels(asks, 'resistance', this.depthToAnalyze);
      
      // Analyze liquidity profile
      const liquidityProfile = this.analyzeLiquidityProfile(bids, asks);
      
      return {
        buyPressure: totalBidVolume,
        sellPressure: totalAskVolume,
        imbalanceRatio,
        dominantSide,
        supportLevels,
        resistanceLevels,
        liquidityProfile
      };
    } catch (error) {
      logger.error(`Error analyzing orderbook: ${error.message}`);
      return {
        buyPressure: 0,
        sellPressure: 0,
        imbalanceRatio: 1,
        dominantSide: 'neutral',
        supportLevels: [],
        resistanceLevels: [],
        liquidityProfile: 'neutral'
      };
    }
  }
  
  // Calculate total volume for a specified depth
  calculateTotalVolume(orders, depth) {
    let total = 0;
    const maxDepth = Math.min(depth, orders.length);
    
    for (let i = 0; i < maxDepth; i++) {
      // Bybit orderbook format: [price, size]
      total += parseFloat(orders[i][1]);
    }
    
    return total;
  }
  
  // Find significant liquidity levels (support/resistance)
  findLiquidityLevels(orders, type, depth) {
    const levels = [];
    const averageVolume = this.calculateAverageVolume(orders, depth);
    const significanceThreshold = averageVolume * 2; // 2x average volume is significant
    
    // Group close price levels
    const groupedOrders = this.groupByPriceLevel(orders, depth);
    
    // Find significant levels
    for (const level of groupedOrders) {
      if (level.volume >= significanceThreshold) {
        levels.push({
          price: level.price,
          volume: level.volume,
          type,
          strength: level.volume / averageVolume // Relative strength
        });
      }
    }
    
    // Sort by strength (descending)
    return levels.sort((a, b) => b.strength - a.strength);
  }
  
  // Calculate average volume per level
  calculateAverageVolume(orders, depth) {
    const total = this.calculateTotalVolume(orders, depth);
    return total / Math.min(depth, orders.length);
  }
  
  // Group orders by price level (within 0.1% range)
  groupByPriceLevel(orders, depth) {
    const groupedLevels = [];
    const maxDepth = Math.min(depth, orders.length);
    
    for (let i = 0; i < maxDepth; i++) {
      const price = parseFloat(orders[i][0]);
      const volume = parseFloat(orders[i][1]);
      
      // Find if we have a close price level already
      let foundGroup = false;
      for (const group of groupedLevels) {
        // If price is within 0.1% of group price, add to group
        if (Math.abs(price - group.price) / group.price < 0.001) {
          group.volume += volume;
          // Update price to weighted average
          group.price = ((group.price * group.count) + price) / (group.count + 1);
          group.count += 1;
          foundGroup = true;
          break;
        }
      }
      
      // If no close group found, create a new one
      if (!foundGroup) {
        groupedLevels.push({
          price,
          volume,
          count: 1
        });
      }
    }
    
    return groupedLevels;
  }
  
  // Analyze liquidity profile (distribution of orders)
  analyzeLiquidityProfile(bids, asks) {
    try {
      const bidStdev = this.calculateLiquiditySpread(bids, this.depthToAnalyze);
      const askStdev = this.calculateLiquiditySpread(asks, this.depthToAnalyze);
      
      // Determine liquidity distribution pattern
      if (bidStdev > askStdev * 1.5) {
        return 'scattered_bids'; // Bids are scattered, less conviction
      } else if (askStdev > bidStdev * 1.5) {
        return 'scattered_asks'; // Asks are scattered, less conviction
      } else if (bidStdev < 0.02 && askStdev < 0.02) {
        return 'tight_range'; // Tight range, potential breakout
      } else {
        return 'balanced'; // Balanced distribution
      }
    } catch (error) {
      logger.error(`Error analyzing liquidity profile: ${error.message}`);
      return 'unknown';
    }
  }
  
  // Calculate the spread of liquidity (standard deviation of volumes)
  calculateLiquiditySpread(orders, depth) {
    try {
      const volumes = orders.slice(0, depth).map(order => parseFloat(order[1]));
      const avg = volumes.reduce((sum, vol) => sum + vol, 0) / volumes.length;
      
      // Calculate standard deviation
      const sumSquaredDiff = volumes.reduce((sum, vol) => sum + Math.pow(vol - avg, 2), 0);
      const stdev = Math.sqrt(sumSquaredDiff / volumes.length);
      
      // Normalize by average volume
      return stdev / avg;
    } catch (error) {
      logger.error(`Error calculating liquidity spread: ${error.message}`);
      return 0;
    }
  }
  
  // Check if current price is near a significant support or resistance level
  isPriceNearSignificantLevel(currentPrice, levels, proximityPercent = 0.5) {
    for (const level of levels) {
      const proximity = Math.abs(currentPrice - level.price) / currentPrice * 100;
      if (proximity <= proximityPercent) {
        return {
          isNear: true,
          level,
          proximity
        };
      }
    }
    
    return {
      isNear: false
    };
  }
  
  // Determine potential trade opportunities based on orderbook analysis
  evaluateTradingOpportunity(analysis, currentPrice) {
    try {
      const { dominantSide, supportLevels, resistanceLevels, imbalanceRatio, liquidityProfile } = analysis;
      
      // Check if price is near significant support/resistance
      const nearSupport = this.isPriceNearSignificantLevel(currentPrice, supportLevels);
      const nearResistance = this.isPriceNearSignificantLevel(currentPrice, resistanceLevels);
      
      let signal = 'neutral';
      let confidence = 0;
      let reason = '';
      
      // Determine potential signals
      if (dominantSide === 'buy' && nearSupport.isNear) {
        signal = 'long';
        confidence = Math.min(imbalanceRatio / this.imbalanceThreshold, 1) * 
                    (1 - nearSupport.proximity / 0.5); // Higher confidence if closer to support
        reason = 'Strong buy pressure near support level';
      } else if (dominantSide === 'sell' && nearResistance.isNear) {
        signal = 'short';
        confidence = Math.min((1 / imbalanceRatio) / this.imbalanceThreshold, 1) * 
                    (1 - nearResistance.proximity / 0.5); // Higher confidence if closer to resistance
        reason = 'Strong sell pressure near resistance level';
      } else if (dominantSide === 'buy' && liquidityProfile === 'tight_range') {
        signal = 'long';
        confidence = 0.6; // Medium confidence
        reason = 'Buy pressure with tight liquidity range, potential breakout';
      } else if (dominantSide === 'sell' && liquidityProfile === 'tight_range') {
        signal = 'short';
        confidence = 0.6; // Medium confidence
        reason = 'Sell pressure with tight liquidity range, potential breakout';
      }
      
      return {
        signal,
        confidence,
        reason,
        nearSupport: nearSupport.isNear ? nearSupport : null,
        nearResistance: nearResistance.isNear ? nearResistance : null
      };
    } catch (error) {
      logger.error(`Error evaluating trading opportunity: ${error.message}`);
      return {
        signal: 'neutral',
        confidence: 0,
        reason: 'Error in analysis'
      };
    }
  }
}

module.exports = OrderbookAnalysis;