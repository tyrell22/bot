// Basic Technical Indicators
const logger = require('../utils/logger');

class BasicIndicators {
  constructor(config) {
    this.config = config;
  }
  
  // Process candle data into usable arrays
  processCandles(klines) {
    // Bybit klines structure: [timestamp, open, high, low, close, volume, turnover]
    // We need to reverse as they come in descending order (newest first)
    const timestamps = klines.map(candle => parseInt(candle[0])).reverse();
    const opens = klines.map(candle => parseFloat(candle[1])).reverse();
    const highs = klines.map(candle => parseFloat(candle[2])).reverse();
    const lows = klines.map(candle => parseFloat(candle[3])).reverse();
    const closes = klines.map(candle => parseFloat(candle[4])).reverse();
    const volumes = klines.map(candle => parseFloat(candle[5])).reverse();
    
    return {
      timestamps,
      opens,
      highs,
      lows,
      closes,
      volumes
    };
  }
  
  // Calculate Simple Moving Average
  calculateSMA(data, period) {
    const result = [];
    
    for (let i = 0; i < data.length; i++) {
      if (i < period - 1) {
        result.push(null);
        continue;
      }
      
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += data[i - j];
      }
      
      result.push(sum / period);
    }
    
    return result;
  }
  
  // Calculate Exponential Moving Average
  calculateEMA(data, period) {
    const result = [];
    const multiplier = 2 / (period + 1);
    
    // Start with SMA
    let ema = data.slice(0, period).reduce((sum, price) => sum + price, 0) / period;
    result.push(ema);
    
    // Calculate EMA for remaining data
    for (let i = period; i < data.length; i++) {
      ema = (data[i] - ema) * multiplier + ema;
      result.push(ema);
    }
    
    // Pad the beginning with nulls
    const padding = Array(data.length - result.length).fill(null);
    return [...padding, ...result];
  }
  
  // Calculate RSI (Relative Strength Index)
  calculateRSI(data, period) {
    const result = Array(period).fill(null);
    let gains = 0;
    let losses = 0;
    
    // Calculate first average gain and loss
    for (let i = 1; i <= period; i++) {
      const change = data[i] - data[i - 1];
      if (change >= 0) {
        gains += change;
      } else {
        losses -= change;
      }
    }
    
    let avgGain = gains / period;
    let avgLoss = losses / period;
    
    // Calculate RSI for first data point
    let rs = avgGain / avgLoss;
    let rsi = 100 - (100 / (1 + rs));
    result.push(rsi);
    
    // Calculate remaining RSI values
    for (let i = period + 1; i < data.length; i++) {
      const change = data[i] - data[i - 1];
      let currentGain = 0;
      let currentLoss = 0;
      
      if (change >= 0) {
        currentGain = change;
      } else {
        currentLoss = -change;
      }
      
      avgGain = ((avgGain * (period - 1)) + currentGain) / period;
      avgLoss = ((avgLoss * (period - 1)) + currentLoss) / period;
      
      rs = avgGain / avgLoss;
      rsi = 100 - (100 / (1 + rs));
      result.push(rsi);
    }
    
    return result;
  }
  
  // Calculate MACD (Moving Average Convergence Divergence)
  calculateMACD(data, fastPeriod, slowPeriod, signalPeriod) {
    const fastEMA = this.calculateEMA(data, fastPeriod);
    const slowEMA = this.calculateEMA(data, slowPeriod);
    
    // Calculate MACD line
    const macdLine = fastEMA.map((fast, index) => {
      if (fast === null || slowEMA[index] === null) return null;
      return fast - slowEMA[index];
    });
    
    // Calculate valid MACD values (non-null)
    const validMacd = macdLine.filter(value => value !== null);
    
    // Calculate signal line using EMA of MACD line
    const signalLine = this.calculateEMA(validMacd, signalPeriod);
    
    // Pad signal line with nulls to match original data length
    const paddedSignalLine = Array(macdLine.length - signalLine.length).fill(null).concat(signalLine);
    
    // Calculate histogram (MACD line - signal line)
    const histogram = macdLine.map((macd, index) => {
      if (macd === null || paddedSignalLine[index] === null) return null;
      return macd - paddedSignalLine[index];
    });
    
    return {
      macdLine,
      signalLine: paddedSignalLine,
      histogram
    };
  }
  
  // Calculate Bollinger Bands
  calculateBollingerBands(data, period, stdDev) {
    const middle = this.calculateSMA(data, period);
    const upper = [];
    const lower = [];
    
    for (let i = 0; i < data.length; i++) {
      if (middle[i] === null) {
        upper.push(null);
        lower.push(null);
        continue;
      }
      
      // Calculate standard deviation
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += Math.pow(data[i - j] - middle[i], 2);
      }
      
      const sd = Math.sqrt(sum / period);
      
      upper.push(middle[i] + (sd * stdDev));
      lower.push(middle[i] - (sd * stdDev));
    }
    
    return {
      upper,
      middle,
      lower
    };
  }
  
  // Calculate Average True Range
  calculateATR(highs, lows, closes, period) {
    const trueRanges = [];
    
    // Calculate True Range for each candle
    for (let i = 0; i < highs.length; i++) {
      if (i === 0) {
        // First candle, TR is simply High - Low
        trueRanges.push(highs[i] - lows[i]);
      } else {
        // Consider previous close
        const tr1 = highs[i] - lows[i]; // Current high - current low
        const tr2 = Math.abs(highs[i] - closes[i - 1]); // Current high - previous close
        const tr3 = Math.abs(lows[i] - closes[i - 1]); // Current low - previous close
        
        trueRanges.push(Math.max(tr1, tr2, tr3));
      }
    }
    
    // Calculate ATR using Simple Moving Average of True Ranges
    return this.calculateSMA(trueRanges, period);
  }
  
  // Calculate Stochastic Oscillator
  calculateStochastic(highs, lows, closes, kPeriod = 14, dPeriod = 3) {
    const k = [];
    
    // Calculate %K
    for (let i = 0; i < closes.length; i++) {
      if (i < kPeriod - 1) {
        k.push(null);
        continue;
      }
      
      // Find highest high and lowest low in the period
      let highestHigh = -Infinity;
      let lowestLow = Infinity;
      
      for (let j = 0; j < kPeriod; j++) {
        const high = highs[i - j];
        const low = lows[i - j];
        
        if (high > highestHigh) highestHigh = high;
        if (low < lowestLow) lowestLow = low;
      }
      
      // Calculate %K
      const currentK = ((closes[i] - lowestLow) / (highestHigh - lowestLow)) * 100;
      k.push(currentK);
    }
    
    // Calculate %D (SMA of %K)
    const d = this.calculateSMA(k.filter(val => val !== null), dPeriod);
    
    // Pad %D with nulls to match original data length
    const paddedD = Array(k.length - d.length).fill(null).concat(d);
    
    return {
      k,
      d: paddedD
    };
  }
  
  // Calculate all basic indicators
  calculateAllIndicators(klines) {
    try {
      const { timestamps, opens, highs, lows, closes, volumes } = this.processCandles(klines);
      
      // Calculate EMAs
      const ema9 = this.calculateEMA(closes, this.config.indicators.ema.short);
      const ema21 = this.calculateEMA(closes, this.config.indicators.ema.long);
      
      // Calculate RSI
      const rsi = this.calculateRSI(closes, this.config.indicators.rsi.period);
      
      // Calculate MACD
      const macd = this.calculateMACD(
        closes, 
        this.config.indicators.macd.fast, 
        this.config.indicators.macd.slow, 
        this.config.indicators.macd.signal
      );
      
      // Calculate Bollinger Bands
      const bbands = this.calculateBollingerBands(
        closes, 
        this.config.indicators.bbands.period, 
        this.config.indicators.bbands.stdDev
      );
      
      // Calculate ATR
      const atr = this.calculateATR(highs, lows, closes, 14);
      
      // Calculate Stochastic
      const stoch = this.calculateStochastic(highs, lows, closes, 14, 3);
      
      return {
        timestamps,
        opens,
        highs,
        lows,
        closes,
        volumes,
        ema9,
        ema21,
        rsi,
        macd,
        bbands,
        atr,
        stoch
      };
    } catch (error) {
      logger.error(`Error calculating indicators: ${error.message}`);
      throw error;
    }
  }
}