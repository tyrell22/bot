// VWAP (Volume Weighted Average Price) Indicator
const logger = require('../utils/logger');

class VWAPIndicator {
  constructor(config) {
    this.config = config;
    this.periodHours = config.indicators.vwap.period || 24; // default to 24 hours
  }
  
  // Calculate VWAP for a given time period
  calculateVWAP(klines) {
    try {
      // Convert klines to the format needed for VWAP
      // Bybit klines structure: [timestamp, open, high, low, close, volume, turnover]
      // We need to reverse as they come in descending order (newest first)
      const data = klines.map(candle => ({
        timestamp: parseInt(candle[0]),
        open: parseFloat(candle[1]),
        high: parseFloat(candle[2]),
        low: parseFloat(candle[3]),
        close: parseFloat(candle[4]),
        volume: parseFloat(candle[5]),
        turnover: parseFloat(candle[6])
      })).reverse();
      
      // Calculate typical price and cumulative values for each period
      let cumulativeTPV = 0; // Typical Price * Volume
      let cumulativeVolume = 0;
      const vwapValues = [];
      const upperBand = [];
      const lowerBand = [];
      
      // Determine time cutoff for the VWAP period
      const latestTimestamp = data[data.length - 1].timestamp;
      const periodStart = latestTimestamp - (this.periodHours * 60 * 60 * 1000);
      
      // Standard deviation calculation variables
      let squaredDifferences = 0;
      let countForStdDev = 0;
      
      for (let i = 0; i < data.length; i++) {
        const candle = data[i];
        
        // Only include candles within the time period
        if (candle.timestamp < periodStart) {
          vwapValues.push(null);
          upperBand.push(null);
          lowerBand.push(null);
          continue;
        }
        
        // Calculate typical price: (High + Low + Close) / 3
        const typicalPrice = (candle.high + candle.low + candle.close) / 3;
        
        // Update cumulative values
        cumulativeTPV += typicalPrice * candle.volume;
        cumulativeVolume += candle.volume;
        
        // Calculate VWAP
        const vwap = cumulativeTPV / cumulativeVolume;
        vwapValues.push(vwap);
        
        // Update squared differences for standard deviation
        squaredDifferences += Math.pow(candle.close - vwap, 2);
        countForStdDev++;
        
        // Calculate standard deviation-based bands
        if (countForStdDev > 1) {
          const stdDev = Math.sqrt(squaredDifferences / countForStdDev);
          upperBand.push(vwap + (2 * stdDev));
          lowerBand.push(vwap - (2 * stdDev));
        } else {
          upperBand.push(null);
          lowerBand.push(null);
        }
      }
      
      return {
        vwap: vwapValues,
        upperBand,
        lowerBand
      };
    } catch (error) {
      logger.error(`Error calculating VWAP: ${error.message}`);
      throw error;
    }
  }
  
  // Reset VWAP at session boundaries (e.g., daily)
  resetVWAPAtSessionBoundary(klines) {
    try {
      // Convert klines to the format needed for VWAP with timestamps
      const data = klines.map(candle => ({
        timestamp: parseInt(candle[0]),
        open: parseFloat(candle[1]),
        high: parseFloat(candle[2]),
        low: parseFloat(candle[3]),
        close: parseFloat(candle[4]),
        volume: parseFloat(candle[5]),
        turnover: parseFloat(candle[6])
      })).reverse();
      
      const vwapValues = [];
      const upperBand = [];
      const lowerBand = [];
      
      let cumulativeTPV = 0;
      let cumulativeVolume = 0;
      let sessionDate = '';
      let squaredDifferences = 0;
      let countForStdDev = 0;
      
      for (let i = 0; i < data.length; i++) {
        const candle = data[i];
        const date = new Date(candle.timestamp);
        const currentDate = date.toISOString().split('T')[0]; // Get YYYY-MM-DD format
        
        // Reset cumulative values if we're in a new session (day)
        if (currentDate !== sessionDate) {
          sessionDate = currentDate;
          cumulativeTPV = 0;
          cumulativeVolume = 0;
          squaredDifferences = 0;
          countForStdDev = 0;
        }
        
        // Calculate typical price: (High + Low + Close) / 3
        const typicalPrice = (candle.high + candle.low + candle.close) / 3;
        
        // Update cumulative values
        cumulativeTPV += typicalPrice * candle.volume;
        cumulativeVolume += candle.volume;
        
        // Calculate VWAP
        if (cumulativeVolume === 0) {
          vwapValues.push(null);
          upperBand.push(null);
          lowerBand.push(null);
        } else {
          const vwap = cumulativeTPV / cumulativeVolume;
          vwapValues.push(vwap);
          
          // Update squared differences for standard deviation
          squaredDifferences += Math.pow(candle.close - vwap, 2);
          countForStdDev++;
          
          // Calculate standard deviation-based bands
          if (countForStdDev > 1) {
            const stdDev = Math.sqrt(squaredDifferences / countForStdDev);
            upperBand.push(vwap + (2 * stdDev));
            lowerBand.push(vwap - (2 * stdDev));
          } else {
            upperBand.push(null);
            lowerBand.push(null);
          }
        }
      }
      
      return {
        vwap: vwapValues,
        upperBand,
        lowerBand
      };
    } catch (error) {
      logger.error(`Error calculating session-based VWAP: ${error.message}`);
      throw error;
    }
  }
  
  // Analyze price relative to VWAP
  analyzeVWAPPosition(currentPrice, vwapData, index) {
    try {
      if (!vwapData || !vwapData.vwap || vwapData.vwap[index] === null) {
        return {
          position: 'unknown',
          distancePercent: 0,
          bandPosition: 'unknown'
        };
      }
      
      const vwap = vwapData.vwap[index];
      const upperBand = vwapData.upperBand[index];
      const lowerBand = vwapData.lowerBand[index];
      
      // Calculate distance from VWAP as percentage
      const distancePercent = ((currentPrice - vwap) / vwap) * 100;
      
      // Determine position relative to VWAP
      let position = 'at_vwap';
      if (distancePercent > 0.1) position = 'above';
      if (distancePercent < -0.1) position = 'below';
      
      // Determine position relative to bands
      let bandPosition = 'inside';
      if (upperBand !== null && currentPrice > upperBand) bandPosition = 'above';
      if (lowerBand !== null && currentPrice < lowerBand) bandPosition = 'below';
      
      return {
        position,
        distancePercent,
        bandPosition
      };
    } catch (error) {
      logger.error(`Error analyzing VWAP position: ${error.message}`);
      return {
        position: 'unknown',
        distancePercent: 0,
        bandPosition: 'unknown'
      };
    }
  }
}

module.exports = VWAPIndicator;