// Bybit API Client
const axios = require('axios');
const crypto = require('crypto');
const logger = require('../utils/logger');

class BybitApi {
  constructor(config) {
    this.apiKey = config.apiKey;
    this.apiSecret = config.apiSecret;
    this.baseURL = 'https://api.bybit.com';
    this.recvWindow = 5000;
  }
  
  // Test API connection
  async testConnection() {
    try {
      const endpoint = '/v5/market/time';
      const response = await this.makeRequest(endpoint, 'GET');
      return response.result;
    } catch (error) {
      logger.error(`API connection test failed: ${error.message}`);
      throw new Error('API connection test failed');
    }
  }
  
  // Generate signature for API authentication
  generateSignature(timestamp, params = {}) {
    const queryString = timestamp + this.apiKey + this.recvWindow + JSON.stringify(params);
    return crypto.createHmac('sha256', this.apiSecret).update(queryString).digest('hex');
  }
  
  // Make authenticated API request to Bybit
  async makeRequest(endpoint, method = 'GET', params = {}) {
    const timestamp = Date.now().toString();
    const signature = this.generateSignature(timestamp, params);
    
    const headers = {
      'X-BAPI-API-KEY': this.apiKey,
      'X-BAPI-SIGN': signature,
      'X-BAPI-TIMESTAMP': timestamp,
      'X-BAPI-RECV-WINDOW': this.recvWindow.toString(),
      'Content-Type': 'application/json'
    };
    
    try {
      const url = `${this.baseURL}${endpoint}`;
      const response = method === 'GET' 
        ? await axios.get(url, { headers, params })
        : await axios.post(url, params, { headers });
      
      if (response.data.retCode !== 0) {
        throw new Error(`API Error ${response.data.retCode}: ${response.data.retMsg}`);
      }
      
      return response.data;
    } catch (error) {
      logger.error(`API request failed: ${error.message}`);
      if (error.response) {
        logger.error(`Response data: ${JSON.stringify(error.response.data)}`);
      }
      throw error;
    }
  }
  
  // Get account balance
  async getBalance() {
    const endpoint = '/v5/account/wallet-balance';
    const params = { accountType: 'CONTRACT' };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result;
  }
  
  // Get klines (candlestick data)
  async getKlines(symbol, interval = '1m', limit = 100) {
    const endpoint = '/v5/market/kline';
    const params = { symbol, interval, limit };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result.list;
  }
  
  // Get ticker data
  async getTicker(symbol) {
    const endpoint = '/v5/market/ticker';
    const params = { symbol };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result.list[0];
  }
  
  // Get orderbook
  async getOrderbook(symbol, limit = 50) {
    const endpoint = '/v5/market/orderbook';
    const params = { symbol, limit };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result;
  }
  
  // Get recent trades
  async getRecentTrades(symbol, limit = 50) {
    const endpoint = '/v5/market/recent-trade';
    const params = { symbol, limit };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result.list;
  }
  
  // Set leverage for a symbol
  async setLeverage(symbol, leverage) {
    const endpoint = '/v5/position/set-leverage';
    const params = {
      symbol,
      buyLeverage: leverage.toString(),
      sellLeverage: leverage.toString()
    };
    
    try {
      const response = await this.makeRequest(endpoint, 'POST', params);
      return response.result;
    } catch (error) {
      // Leverage may already be set
      if (error.message.includes('same as current')) {
        logger.debug(`Leverage for ${symbol} already set to ${leverage}x`);
        return { success: true };
      }
      throw error;
    }
  }
  
  // Place an order
  async placeOrder(symbol, side, orderType, qty, price = null, reduceOnly = false) {
    const endpoint = '/v5/order/create';
    const params = {
      symbol,
      side,
      orderType,
      qty: qty.toString(),
      timeInForce: 'GTC',
      reduceOnly: reduceOnly,
      positionIdx: 0, // 0: one-way mode
    };
    
    if (price) {
      params.price = price.toString();
    }
    
    const response = await this.makeRequest(endpoint, 'POST', params);
    return response.result;
  }
  
  // Place a conditional order (stop loss, take profit)
  async placeConditionalOrder(symbol, side, orderType, qty, triggerPrice, price = null, reduceOnly = true) {
    const endpoint = '/v5/order/create';
    const params = {
      symbol,
      side,
      orderType,
      qty: qty.toString(),
      triggerPrice: triggerPrice.toString(),
      timeInForce: 'GTC',
      reduceOnly: reduceOnly,
      positionIdx: 0,
      triggerBy: 'LastPrice' // Use 'LastPrice', 'IndexPrice', or 'MarkPrice'
    };
    
    if (price) {
      params.price = price.toString();
    }
    
    const response = await this.makeRequest(endpoint, 'POST', params);
    return response.result;
  }
  
  // Get active orders
  async getActiveOrders(symbol) {
    const endpoint = '/v5/order/realtime';
    const params = { symbol, category: 'linear' };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result.list;
  }
  
  // Cancel an order
  async cancelOrder(symbol, orderId) {
    const endpoint = '/v5/order/cancel';
    const params = { symbol, orderId };
    const response = await this.makeRequest(endpoint, 'POST', params);
    return response.result;
  }
  
  // Get position information
  async getPosition(symbol) {
    const endpoint = '/v5/position/list';
    const params = { symbol, settleCoin: 'USDT' };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result.list.length > 0 ? response.result.list[0] : null;
  }
  
  // Get all positions
  async getAllPositions() {
    const endpoint = '/v5/position/list';
    const params = { settleCoin: 'USDT' };
    const response = await this.makeRequest(endpoint, 'GET', params);
    return response.result.list;
  }
}

module.exports = BybitApi;