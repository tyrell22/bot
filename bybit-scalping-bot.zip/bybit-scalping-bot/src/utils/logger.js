// Logging Utility
const fs = require('fs');
const path = require('path');

class Logger {
  constructor() {
    this.config = {
      level: 'info', // debug, info, warn, error
      file: null,
      logToConsole: true
    };
    
    this.logLevels = {
      debug: 0,
      info: 1,
      warn: 2,
      error: 3
    };
    
    this.logStream = null;
  }
  
  // Configure the logger
  configure(config) {
    if (config) {
      this.config = { ...this.config, ...config };
    }
    
    // Set up log file if specified
    if (this.config.file) {
      const logDir = path.dirname(this.config.file);
      
      // Create log directory if it doesn't exist
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }
      
      // Create or open log file
      this.logStream = fs.createWriteStream(this.config.file, { flags: 'a' });
      
      // Handle stream errors
      this.logStream.on('error', (err) => {
        console.error(`Error writing to log file: ${err.message}`);
        this.logStream = null;
      });
    }
  }
  
  // Format message with timestamp
  formatMessage(level, message) {
    const timestamp = new Date().toISOString();
    return `[${timestamp}] [${level.toUpperCase()}] ${message}`;
  }
  
  // Write log message
  log(level, message) {
    // Check if log level is enabled
    if (this.logLevels[level] < this.logLevels[this.config.level]) {
      return;
    }
    
    const formattedMessage = this.formatMessage(level, message);
    
    // Log to console if enabled
    if (this.config.logToConsole) {
      // Add colors for console output
      let consoleMethod = console.log;
      let coloredMessage = formattedMessage;
      
      switch (level) {
        case 'debug':
          consoleMethod = console.debug;
          coloredMessage = `\x1b[36m${formattedMessage}\x1b[0m`; // Cyan
          break;
        case 'info':
          consoleMethod = console.info;
          coloredMessage = `\x1b[32m${formattedMessage}\x1b[0m`; // Green
          break;
        case 'warn':
          consoleMethod = console.warn;
          coloredMessage = `\x1b[33m${formattedMessage}\x1b[0m`; // Yellow
          break;
        case 'error':
          consoleMethod = console.error;
          coloredMessage = `\x1b[31m${formattedMessage}\x1b[0m`; // Red
          break;
      }
      
      consoleMethod(coloredMessage);
    }
    
    // Log to file if enabled
    if (this.logStream) {
      this.logStream.write(`${formattedMessage}\n`);
    }
  }
  
  // Convenience methods for each log level
  debug(message) {
    this.log('debug', message);
  }
  
  info(message) {
    this.log('info', message);
  }
  
  warn(message) {
    this.log('warn', message);
  }
  
  error(message) {
    this.log('error', message);
  }
  
  // Close logging
  close() {
    if (this.logStream) {
      this.logStream.end();
      this.logStream = null;
    }
  }
}

// Create and export singleton instance
const logger = new Logger();

// Configure logger with default settings
logger.configure({
  level: process.env.LOG_LEVEL || 'info',
  file: process.env.LOG_FILE || 'logs/scalping-bot.log',
  logToConsole: process.env.LOG_CONSOLE !== 'false'
});

module.exports = logger;