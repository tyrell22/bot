// Data Storage Utility
const fs = require('fs');
const path = require('path');
const logger = require('./logger');

class Storage {
  constructor() {
    // Storage directories
    this.dataDir = path.join(process.cwd(), 'data');
    this.tradesFile = path.join(this.dataDir, 'trades.json');
    this.backtestDir = path.join(this.dataDir, 'backtest');
    
    // Create directories if they don't exist
    this.createDirectories();
  }
  
  // Create necessary directories
  createDirectories() {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
      logger.info(`Created data directory: ${this.dataDir}`);
    }
    
    if (!fs.existsSync(this.backtestDir)) {
      fs.mkdirSync(this.backtestDir, { recursive: true });
      logger.info(`Created backtest directory: ${this.backtestDir}`);
    }
  }
  
  // Save a completed trade
  saveTrade(trade) {
    try {
      // Load existing trades
      let trades = this.loadTrades() || [];
      
      // Add new trade
      trades.push(trade);
      
      // Write to file
      fs.writeFileSync(this.tradesFile, JSON.stringify(trades, null, 2));
      logger.debug(`Saved trade for ${trade.symbol} to storage`);
      
      return true;
    } catch (error) {
      logger.error(`Error saving trade to storage: ${error.message}`);
      return false;
    }
  }
  
  // Load all trades from storage
  loadTrades() {
    try {
      if (!fs.existsSync(this.tradesFile)) {
        return [];
      }
      
      const data = fs.readFileSync(this.tradesFile, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      logger.error(`Error loading trades from storage: ${error.message}`);
      return [];
    }
  }
  
  // Save market data for backtesting
  saveMarketData(symbol, timeframe, data) {
    try {
      const filename = `${symbol}_${timeframe}.json`;
      const filePath = path.join(this.backtestDir, filename);
      
      fs.writeFileSync(filePath, JSON.stringify(data));
      logger.debug(`Saved market data for ${symbol} (${timeframe}) to storage`);
      
      return true;
    } catch (error) {
      logger.error(`Error saving market data: ${error.message}`);
      return false;
    }
  }
  
  // Load market data for backtesting
  loadMarketData(symbol, timeframe) {
    try {
      const filename = `${symbol}_${timeframe}.json`;
      const filePath = path.join(this.backtestDir, filename);
      
      if (!fs.existsSync(filePath)) {
        return null;
      }
      
      const data = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      logger.error(`Error loading market data: ${error.message}`);
      return null;
    }
  }
  
  // Save bot configuration
  saveConfig(config) {
    try {
      const configPath = path.join(process.cwd(), 'config', 'default.json');
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
      logger.info('Configuration saved to config/default.json');
      return true;
    } catch (error) {
      logger.error(`Error saving configuration: ${error.message}`);
      return false;
    }
  }
  
  // Load bot configuration
  loadConfig() {
    try {
      const configPath = path.join(process.cwd(), 'config', 'default.json');
      
      if (!fs.existsSync(configPath)) {
        return null;
      }
      
      const data = fs.readFileSync(configPath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      logger.error(`Error loading configuration: ${error.message}`);
      return null;
    }
  }
  
  // Export trade history to CSV
  exportTradesToCSV() {
    try {
      const trades = this.loadTrades();
      if (!trades || trades.length === 0) {
        logger.warn('No trades to export');
        return false;
      }
      
      // Create CSV header
      const headers = [
        'symbol',
        'side',
        'entryPrice',
        'exitPrice',
        'quantity',
        'leverage',
        'pnl',
        'success',
        'timestamp',
        'closeTime'
      ].join(',');
      
      // Create CSV rows
      const rows = trades.map(trade => [
        trade.symbol,
        trade.side,
        trade.entryPrice,
        trade.exitPrice || '',
        trade.quantity,
        trade.leverage,
        trade.pnl ? (trade.pnl * 100).toFixed(2) + '%' : '',
        trade.success ? 'Yes' : 'No',
        new Date(trade.timestamp).toISOString(),
        trade.closeTime ? new Date(trade.closeTime).toISOString() : ''
      ].join(','));
      
      // Combine header and rows
      const csv = [headers, ...rows].join('\n');
      
      // Write to file
      const exportPath = path.join(this.dataDir, `trade_history_${Date.now()}.csv`);
      fs.writeFileSync(exportPath, csv);
      
      logger.info(`Exported ${trades.length} trades to ${exportPath}`);
      return exportPath;
    } catch (error) {
      logger.error(`Error exporting trades to CSV: ${error.message}`);
      return false;
    }
  }
  
  // Clear all trade history (dangerous!)
  clearTradeHistory() {
    try {
      if (fs.existsSync(this.tradesFile)) {
        // Backup existing file
        const backupPath = `${this.tradesFile}.${Date.now()}.bak`;
        fs.copyFileSync(this.tradesFile, backupPath);
        
        // Delete file
        fs.unlinkSync(this.tradesFile);
        
        logger.warn(`Trade history cleared. Backup created at ${backupPath}`);
        return true;
      }
      
      return false;
    } catch (error) {
      logger.error(`Error clearing trade history: ${error.message}`);
      return false;
    }
  }
}

module.exports = Storage;