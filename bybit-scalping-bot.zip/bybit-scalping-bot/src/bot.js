// Main Bot Class
const BybitApi = require('./api/bybit');
const MarketAnalysis = require('./trading/analysis');
const TradeExecution = require('./trading/execution');
const PositionManager = require('./trading/position');
const MLModel = require('./ml/model');
const logger = require('./utils/logger');
const Storage = require('./utils/storage');

class ScalpingBot {
  constructor(config) {
    this.config = config;
    
    // Initialize components
    this.api = new BybitApi(config);
    this.storage = new Storage();
    this.analysis = new MarketAnalysis(config, this.api);
    this.tradeExecutor = new TradeExecution(config, this.api);
    this.positionManager = new PositionManager(config, this.api, this.storage);
    
    // ML model (optional)
    this.mlModel = config.ml.enabled 
      ? new MLModel(config.ml, this.storage) 
      : null;
    
    // Bot state
    this.isRunning = false;
    this.analysisInterval = null;
    this.positionCheckInterval = null;
    this.completedTrades = [];
    
    // Load previous trades from storage
    this.loadCompletedTrades();
  }
  
  // Load completed trades from storage
  loadCompletedTrades() {
    try {
      this.completedTrades = this.storage.loadTrades() || [];
      logger.info(`Loaded ${this.completedTrades.length} historical trades from storage`);
    } catch (error) {
      logger.error(`Error loading historical trades: ${error.message}`);
      this.completedTrades = [];
    }
  }
  
  // Start the bot
  async start() {
    if (this.isRunning) {
      logger.warn('Bot is already running');
      return;
    }
    
    logger.info('Starting Bybit Scalping Bot...');
    
    try {
      // Test API connection
      await this.api.testConnection();
      logger.info('Successfully connected to Bybit API');
      
      // Set leverage for all symbols
      for (const symbol of this.config.symbols) {
        await this.api.setLeverage(symbol, this.config.leverage);
        logger.info(`Set leverage to ${this.config.leverage}x for ${symbol}`);
      }
      
      // Set up recurring tasks
      this.analysisInterval = setInterval(() => this.analyzeMarkets(), 60000); // Every minute
      this.positionCheckInterval = setInterval(() => this.checkPositions(), 30000); // Every 30 seconds
      
      this.isRunning = true;
      
      // Initial analysis
      await this.analyzeMarkets();
      
    } catch (error) {
      logger.error(`Error starting bot: ${error.message}`);
      this.stop();
    }
  }
  
  // Stop the bot
  async stop() {
    if (!this.isRunning) {
      return;
    }
    
    logger.info('Stopping bot...');
    
    // Clear intervals
    if (this.analysisInterval) {
      clearInterval(this.analysisInterval);
      this.analysisInterval = null;
    }
    
    if (this.positionCheckInterval) {
      clearInterval(this.positionCheckInterval);
      this.positionCheckInterval = null;
    }
    
    this.isRunning = false;
    logger.info('Bot stopped');
  }
  
  // Analyze all markets
  async analyzeMarkets() {
    logger.info(`Analyzing ${this.config.symbols.length} markets...`);
    
    for (const symbol of this.config.symbols) {
      try {
        // Skip symbols with active positions
        if (this.positionManager.hasActivePosition(symbol)) {
          logger.debug(`Skipping analysis for ${symbol} - active position exists`);
          continue;
        }
        
        // Check if we have reached max positions
        if (this.positionManager.getActivePositionsCount() >= this.config.maxPositions) {
          logger.debug(`Maximum number of positions reached (${this.config.maxPositions}), skipping further analysis`);
          break;
        }
        
        // Analyze market for trading opportunities
        const signal = await this.analysis.analyzeSymbol(symbol);
        
        // If we have a valid signal, execute trade
        if (signal) {
          logger.info(`Signal detected for ${symbol}: ${signal.type} with confidence ${signal.confidence.toFixed(2)}`);
          
          // Get ML prediction if available
          let mlPrediction = null;
          if (this.mlModel) {
            mlPrediction = await this.mlModel.predictTrade(signal.indicators);
            if (mlPrediction) {
              logger.info(`ML prediction for ${symbol}: ${mlPrediction.direction} with confidence ${mlPrediction.confidence.toFixed(2)}`);
              
              // Only proceed if ML agrees with signal or has high confidence
              if (mlPrediction.direction !== signal.type && mlPrediction.confidence > 0.7) {
                logger.info(`ML model suggests opposite direction with high confidence, skipping trade`);
                continue;
              }
            }
          }
          
          // Execute the trade
          const trade = await this.tradeExecutor.executeTrade(symbol, signal);
          
          if (trade) {
            // Register the position with the position manager
            this.positionManager.addPosition(trade);
          }
        }
        
        // Small delay between symbols to avoid rate limits
        await new Promise(resolve => setTimeout(resolve, 500));
        
      } catch (error) {
        logger.error(`Error analyzing ${symbol}: ${error.message}`);
      }
    }
  }
  
  // Check active positions
  async checkPositions() {
    try {
      const closedPositions = await this.positionManager.checkPositions();
      
      // Process closed positions
      for (const position of closedPositions) {
        this.completedTrades.push(position);
        this.storage.saveTrade(position);
        
        logger.info(`Position closed for ${position.symbol}. P&L: ${(position.pnl * 100).toFixed(2)}%`);
        
        // Retrain ML model if enabled and we have enough new data
        if (this.mlModel && this.config.ml.enabled && 
            closedPositions.length % this.config.ml.trainInterval === 0) {
          logger.info(`Retraining ML model with ${this.completedTrades.length} trades`);
          await this.mlModel.trainModel();
        }
      }
    } catch (error) {
      logger.error(`Error checking positions: ${error.message}`);
    }
  }
  
  // Get trading performance statistics
  getPerformanceStats() {
    if (this.completedTrades.length === 0) {
      return {
        totalTrades: 0,
        winRate: 0,
        avgProfit: 0,
        totalProfit: 0,
        bestTrade: 0,
        worstTrade: 0
      };
    }
    
    const winningTrades = this.completedTrades.filter(trade => trade.success);
    const winRate = (winningTrades.length / this.completedTrades.length) * 100;
    
    const profits = this.completedTrades.map(trade => trade.pnl);
    const totalProfit = profits.reduce((sum, pnl) => sum + pnl, 0);
    const avgProfit = totalProfit / this.completedTrades.length;
    
    const bestTrade = Math.max(...profits);
    const worstTrade = Math.min(...profits);
    
    return {
      totalTrades: this.completedTrades.length,
      winRate: winRate.toFixed(2),
      avgProfit: (avgProfit * 100).toFixed(2),
      totalProfit: (totalProfit * 100).toFixed(2),
      bestTrade: (bestTrade * 100).toFixed(2),
      worstTrade: (worstTrade * 100).toFixed(2)
    };
  }
}

module.exports = ScalpingBot;