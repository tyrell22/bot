// Market Analysis Logic
const BasicIndicators = require('../indicators/basic');
const VWAPIndicator = require('../indicators/vwap');
const OrderbookAnalysis = require('../indicators/orderbook');
const logger = require('../utils/logger');

class MarketAnalysis {
  constructor(config, api) {
    this.config = config;
    this.api = api;
    
    // Initialize indicators
    this.basicIndicators = new BasicIndicators(config);
    this.vwapIndicator = new VWAPIndicator(config);
    this.orderbookAnalysis = new OrderbookAnalysis(config);
  }
  
  // Analyze a symbol for trading opportunities
  async analyzeSymbol(symbol) {
    try {
      logger.debug(`Analyzing ${symbol}...`);
      
      // Get recent candles
      const klines = await this.api.getKlines(symbol, '1m', 100);
      
      // Get current ticker
      const ticker = await this.api.getTicker(symbol);
      const currentPrice = parseFloat(ticker.lastPrice);
      
      // Get orderbook
      const orderbook = await this.api.getOrderbook(symbol, 50);
      
      // Calculate basic indicators
      const indicators = this.basicIndicators.calculateAllIndicators(klines);
      
      // Calculate VWAP
      const vwap = this.vwapIndicator.calculateVWAP(klines);
      indicators.vwap = vwap;
      
      // Analyze orderbook
      const orderbookAnalysis = this.orderbookAnalysis.analyzeOrderbook(orderbook);
      indicators.orderbook = orderbookAnalysis;
      
      // Check for trading signals
      const signal = this.checkSignals(symbol, indicators, currentPrice);
      
      if (signal) {
        logger.info(`Signal detected for ${symbol}: ${signal.type} with confidence ${signal.confidence.toFixed(2)}`);
        return signal;
      }
      
      return null;
    } catch (error) {
      logger.error(`Error analyzing ${symbol}: ${error.message}`);
      return null;
    }
  }
  
  // Check for trading signals
  checkSignals(symbol, indicators, currentPrice) {
    try {
      const currentIndex = indicators.closes.length - 1;
      
      // Ensure we have enough data
      if (currentIndex < 21) {
        logger.debug(`Not enough data for ${symbol} to generate signals`);
        return null;
      }
      
      // Get current values
      const currentClose = indicators.closes[currentIndex];
      const currentEma9 = indicators.ema9[currentIndex];
      const currentEma21 = indicators.ema21[currentIndex];
      const currentRsi = indicators.rsi[currentIndex];
      const currentMacd = indicators.macd.macdLine[currentIndex];
      const currentSignal = indicators.macd.signalLine[currentIndex];
      const currentHistogram = indicators.macd.histogram[currentIndex];
      const upperBand = indicators.bbands.upper[currentIndex];
      const lowerBand = indicators.bbands.lower[currentIndex];
      
      // Get VWAP values
      const currentVwap = indicators.vwap.vwap[currentIndex];
      const vwapAnalysis = this.vwapIndicator.analyzeVWAPPosition(currentPrice, indicators.vwap, currentIndex);
      
      // Get orderbook analysis
      const orderbookSignal = this.orderbookAnalysis.evaluateTradingOpportunity(
        indicators.orderbook, 
        currentPrice
      );
      
      // Signal variables
      let longSignal = false;
      let shortSignal = false;
      
      // Long signal conditions:
      // 1. EMA9 crosses above EMA21 (bullish crossover)
      const emaCrossoverBullish = indicators.ema9[currentIndex - 1] <= indicators.ema21[currentIndex - 1] && 
                                 currentEma9 > currentEma21;
      
      // 2. RSI crosses above 30 (oversold to neutral)
      const rsiBounce = indicators.rsi[currentIndex - 1] <= 30 && currentRsi > 30;
      
      // 3. MACD crosses above signal line
      const macdCrossoverBullish = indicators.macd.macdLine[currentIndex - 1] <= indicators.macd.signalLine[currentIndex - 1] && 
                                 currentMacd > currentSignal;
      
      // 4. Price bounces off lower Bollinger Band
      const bbandBounce = indicators.closes[currentIndex - 1] <= indicators.bbands.lower[currentIndex - 1] && 
                         currentClose > lowerBand;
      
      // 5. Price below VWAP (potential mean reversion)
      const belowVwap = vwapAnalysis.position === 'below';
      
      // Short signal conditions:
      // 1. EMA9 crosses below EMA21 (bearish crossover)
      const emaCrossoverBearish = indicators.ema9[currentIndex - 1] >= indicators.ema21[currentIndex - 1] && 
                                 currentEma9 < currentEma21;
      
      // 2. RSI crosses below 70 (overbought to neutral)
      const rsiDrop = indicators.rsi[currentIndex - 1] >= 70 && currentRsi < 70;
      
      // 3. MACD crosses below signal line
      const macdCrossoverBearish = indicators.macd.macdLine[currentIndex - 1] >= indicators.macd.signalLine[currentIndex - 1] && 
                                 currentMacd < currentSignal;
      
      // 4. Price bounces off upper Bollinger Band
      const bbandDrop = indicators.closes[currentIndex - 1] >= indicators.bbands.upper[currentIndex - 1] && 
                       currentClose < upperBand;
      
      // 5. Price above VWAP (potential mean reversion)
      const aboveVwap = vwapAnalysis.position === 'above';
      
      // Combine signals with weights
      let longPoints = 0;
      let shortPoints = 0;
      
      if (emaCrossoverBullish) longPoints += 2;
      if (rsiBounce) longPoints += 1.5;
      if (macdCrossoverBullish) longPoints += 2;
      if (bbandBounce) longPoints += 1.5;
      if (belowVwap && vwapAnalysis.bandPosition === 'below') longPoints += 2;
      
      if (emaCrossoverBearish) shortPoints += 2;
      if (rsiDrop) shortPoints += 1.5;
      if (macdCrossoverBearish) shortPoints += 2;
      if (bbandDrop) shortPoints += 1.5;
      if (aboveVwap && vwapAnalysis.bandPosition === 'above') shortPoints += 2;
      
      // Add orderbook analysis points
      if (orderbookSignal.signal === 'long') {
        longPoints += 1.5 * orderbookSignal.confidence;
      } else if (orderbookSignal.signal === 'short') {
        shortPoints += 1.5 * orderbookSignal.confidence;
      }
      
      // Decision threshold
      const threshold = 3.5;
      
      // Generate signal
      if (longPoints >= threshold) {
        return {
          type: 'long',
          price: currentPrice,
          confidence: longPoints / 9, // Normalize confidence
          indicators: {
            ema9: currentEma9,
            ema21: currentEma21,
            rsi: currentRsi,
            macd: currentMacd,
            signal: currentSignal,
            histogram: currentHistogram,
            upperBand,
            lowerBand,
            vwap: currentVwap,
            vwapAnalysis,
            orderbook: indicators.orderbook
          },
          reasons: this.collectSignalReasons(true, {
            emaCrossoverBullish,
            rsiBounce,
            macdCrossoverBullish,
            bbandBounce,
            vwapPosition: vwapAnalysis,
            orderbookSignal
          })
        };
      }
      
      if (shortPoints >= threshold) {
        return {
          type: 'short',
          price: currentPrice,
          confidence: shortPoints / 9, // Normalize confidence
          indicators: {
            ema9: currentEma9,
            ema21: currentEma21,
            rsi: currentRsi,
            macd: currentMacd,
            signal: currentSignal,
            histogram: currentHistogram,
            upperBand,
            lowerBand,
            vwap: currentVwap,
            vwapAnalysis,
            orderbook: indicators.orderbook
          },
          reasons: this.collectSignalReasons(false, {
            emaCrossoverBearish,
            rsiDrop,
            macdCrossoverBearish,
            bbandDrop,
            vwapPosition: vwapAnalysis,
            orderbookSignal
          })
        };
      }
      
      return null;
    } catch (error) {
      logger.error(`Error checking signals: ${error.message}`);
      return null;
    }
  }
  
  // Collect reasons for a signal
  collectSignalReasons(isLong, conditions) {
    const reasons = [];
    
    if (isLong) {
      if (conditions.emaCrossoverBullish) {
        reasons.push('EMA9 crossed above EMA21 (bullish)');
      }
      if (conditions.rsiBounce) {
        reasons.push('RSI bounced from oversold territory');
      }
      if (conditions.macdCrossoverBullish) {
        reasons.push('MACD crossed above signal line');
      }
      if (conditions.bbandBounce) {
        reasons.push('Price bounced off lower Bollinger Band');
      }
      if (conditions.vwapPosition && conditions.vwapPosition.position === 'below') {
        reasons.push(`Price ${conditions.vwapPosition.distancePercent.toFixed(2)}% below VWAP`);
      }
      if (conditions.orderbookSignal && conditions.orderbookSignal.signal === 'long') {
        reasons.push(`Orderbook analysis: ${conditions.orderbookSignal.reason}`);
      }
    } else {
      if (conditions.emaCrossoverBearish) {
        reasons.push('EMA9 crossed below EMA21 (bearish)');
      }
      if (conditions.rsiDrop) {
        reasons.push('RSI dropped from overbought territory');
      }
      if (conditions.macdCrossoverBearish) {
        reasons.push('MACD crossed below signal line');
      }
      if (conditions.bbandDrop) {
        reasons.push('Price dropped from upper Bollinger Band');
      }
      if (conditions.vwapPosition && conditions.vwapPosition.position === 'above') {
        reasons.push(`Price ${conditions.vwapPosition.distancePercent.toFixed(2)}% above VWAP`);
      }
      if (conditions.orderbookSignal && conditions.orderbookSignal.signal === 'short') {
        reasons.push(`Orderbook analysis: ${conditions.orderbookSignal.reason}`);
      }
    }
    
    return reasons;
  }
}

module.exports = MarketAnalysis;