// Trade Execution Logic
const logger = require('../utils/logger');

class TradeExecution {
  constructor(config, api) {
    this.config = config;
    this.api = api;
    
    // Trading parameters
    this.leverage = config.leverage || 10;
    this.profitTarget = config.profitTarget || 0.03;  // 3%
    this.stopLoss = config.stopLoss || 0.04;  // 4%
    this.positionSize = config.positionSize || 0.1;  // 10% of balance
  }
  
  // Execute a trade based on signal
  async executeTrade(symbol, signal) {
    try {
      logger.info(`Executing ${signal.type} trade for ${symbol} at ${signal.price}`);
      
      // Get account balance
      const accountInfo = await this.api.getBalance();
      const balance = parseFloat(accountInfo.coin[0].walletBalance);
      
      // Calculate position size
      const positionAmount = balance * this.positionSize;
      logger.debug(`Using ${(this.positionSize * 100).toFixed(2)}% of balance (${positionAmount.toFixed(4)} USDT)`);
      
      // Set leverage for the symbol (this is already done in bot.js, but just to be safe)
      await this.api.setLeverage(symbol, this.leverage);
      
      // Calculate quantity based on current price and leverage
      const qty = (positionAmount * this.leverage) / signal.price;
      logger.debug(`Trade size: ${qty.toFixed(6)} ${symbol} with ${this.leverage}x leverage`);
      
      // Place the main order
      const side = signal.type === 'long' ? 'Buy' : 'Sell';
      const orderResult = await this.api.placeOrder(symbol, side, 'Market', qty.toFixed(6));
      
      if (!orderResult || !orderResult.orderId) {
        throw new Error(`Failed to place order for ${symbol}`);
      }
      
      logger.info(`${side} order placed for ${symbol}, order ID: ${orderResult.orderId}`);
      
      // Calculate take profit and stop loss prices
      const entryPrice = signal.price;
      const takeProfitPrice = signal.type === 'long' 
        ? entryPrice * (1 + this.profitTarget)
        : entryPrice * (1 - this.profitTarget);
      
      const stopLossPrice = signal.type === 'long'
        ? entryPrice * (1 - this.stopLoss)
        : entryPrice * (1 + this.stopLoss);
      
      logger.debug(`Entry: ${entryPrice.toFixed(4)}, TP: ${takeProfitPrice.toFixed(4)}, SL: ${stopLossPrice.toFixed(4)}`);
      
      // Place take profit order
      const tpSide = signal.type === 'long' ? 'Sell' : 'Buy';
      const tpResult = await this.api.placeOrder(
        symbol, 
        tpSide, 
        'Limit', 
        qty.toFixed(6), 
        takeProfitPrice.toFixed(4),
        true  // reduce only
      );
      
      logger.info(`Take profit order placed for ${symbol} at ${takeProfitPrice.toFixed(4)}, order ID: ${tpResult.orderId}`);
      
      // Place stop loss order
      const slResult = await this.api.placeConditionalOrder(
        symbol,
        tpSide,
        'Market',
        qty.toFixed(6),
        stopLossPrice.toFixed(4),
        null,  // No price for market orders
        true  // reduce only
      );
      
      logger.info(`Stop loss order placed for ${symbol} at ${stopLossPrice.toFixed(4)}, order ID: ${slResult.orderId}`);
      
      // Record the trade
      const trade = {
        symbol,
        orderId: orderResult.orderId,
        tpOrderId: tpResult.orderId,
        slOrderId: slResult.orderId,
        side: signal.type,
        entryPrice,
        takeProfitPrice,
        stopLossPrice,
        quantity: qty,
        leverage: this.leverage,
        timestamp: Date.now(),
        indicators: signal.indicators,
        reasons: signal.reasons
      };
      
      return trade;
    } catch (error) {
      logger.error(`Error executing trade for ${symbol}: ${error.message}`);
      return null;
    }
  }
  
  // Modify take profit or stop loss for an existing position
  async modifyTPSL(trade, newTP = null, newSL = null) {
    try {
      // If neither TP nor SL is provided, do nothing
      if (!newTP && !newSL) {
        return false;
      }
      
      // Cancel existing orders first
      if (newTP && trade.tpOrderId) {
        await this.api.cancelOrder(trade.symbol, trade.tpOrderId);
        logger.info(`Cancelled existing TP order ${trade.tpOrderId} for ${trade.symbol}`);
      }
      
      if (newSL && trade.slOrderId) {
        await this.api.cancelOrder(trade.symbol, trade.slOrderId);
        logger.info(`Cancelled existing SL order ${trade.slOrderId} for ${trade.symbol}`);
      }
      
      // Place new orders
      const side = trade.side === 'long' ? 'Sell' : 'Buy';
      
      // Place new TP order if requested
      if (newTP) {
        const tpResult = await this.api.placeOrder(
          trade.symbol, 
          side, 
          'Limit', 
          trade.quantity.toFixed(6), 
          newTP.toFixed(4),
          true  // reduce only
        );
        
        trade.tpOrderId = tpResult.orderId;
        trade.takeProfitPrice = newTP;
        logger.info(`New take profit order placed for ${trade.symbol} at ${newTP.toFixed(4)}, order ID: ${tpResult.orderId}`);
      }
      
      // Place new SL order if requested
      if (newSL) {
        const slResult = await this.api.placeConditionalOrder(
          trade.symbol,
          side,
          'Market',
          trade.quantity.toFixed(6),
          newSL.toFixed(4),
          null,
          true
        );
        
        trade.slOrderId = slResult.orderId;
        trade.stopLossPrice = newSL;
        logger.info(`New stop loss order placed for ${trade.symbol} at ${newSL.toFixed(4)}, order ID: ${slResult.orderId}`);
      }
      
      return true;
    } catch (error) {
      logger.error(`Error modifying TP/SL for ${trade.symbol}: ${error.message}`);
      return false;
    }
  }
  
  // Handle partial take profits (scaling out)
  async takePartialProfit(trade, percentage = 0.5) {
    try {
      // Calculate quantity to close
      const partialQty = trade.quantity * percentage;
      
      // Place partial take profit
      const side = trade.side === 'long' ? 'Sell' : 'Buy';
      const partialResult = await this.api.placeOrder(
        trade.symbol,
        side,
        'Market',
        partialQty.toFixed(6),
        null,
        true
      );
      
      // Update trade info
      trade.quantity -= partialQty;
      
      // Cancel and replace existing TP order with updated quantity
      if (trade.tpOrderId) {
        await this.api.cancelOrder(trade.symbol, trade.tpOrderId);
        
        const tpResult = await this.api.placeOrder(
          trade.symbol,
          side,
          'Limit',
          trade.quantity.toFixed(6),
          trade.takeProfitPrice.toFixed(4),
          true
        );
        
        trade.tpOrderId = tpResult.orderId;
      }
      
      // Cancel and replace existing SL order with updated quantity
      if (trade.slOrderId) {
        await this.api.cancelOrder(trade.symbol, trade.slOrderId);
        
        const slResult = await this.api.placeConditionalOrder(
          trade.symbol,
          side,
          'Market',
          trade.quantity.toFixed(6),
          trade.stopLossPrice.toFixed(4),
          null,
          true
        );
        
        trade.slOrderId = slResult.orderId;
      }
      
      logger.info(`Took partial profit of ${(percentage * 100).toFixed(0)}% for ${trade.symbol}, remaining quantity: ${trade.quantity.toFixed(6)}`);
      return true;
    } catch (error) {
      logger.error(`Error taking partial profit for ${trade.symbol}: ${error.message}`);
      return false;
    }
  }
  
  // Close a position completely
  async closePosition(trade) {
    try {
      // Cancel any existing orders first
      if (trade.tpOrderId) {
        await this.api.cancelOrder(trade.symbol, trade.tpOrderId);
      }
      
      if (trade.slOrderId) {
        await this.api.cancelOrder(trade.symbol, trade.slOrderId);
      }
      
      // Place market order to close position
      const side = trade.side === 'long' ? 'Sell' : 'Buy';
      const closeResult = await this.api.placeOrder(
        trade.symbol,
        side,
        'Market',
        trade.quantity.toFixed(6),
        null,
        true
      );
      
      logger.info(`Closed position for ${trade.symbol}, order ID: ${closeResult.orderId}`);
      return true;
    } catch (error) {
      logger.error(`Error closing position for ${trade.symbol}: ${error.message}`);
      return false;
    }
  }
}

module.exports = TradeExecution;