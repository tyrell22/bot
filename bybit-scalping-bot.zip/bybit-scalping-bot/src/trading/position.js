// Position Management
const logger = require('../utils/logger');

class PositionManager {
  constructor(config, api, storage) {
    this.config = config;
    this.api = api;
    this.storage = storage;
    this.activePositions = {}; // Symbol -> position mapping
  }
  
  // Add a new position
  addPosition(trade) {
    if (!trade || !trade.symbol) {
      logger.error('Cannot add invalid trade to position manager');
      return false;
    }
    
    this.activePositions[trade.symbol] = trade;
    logger.info(`Added position for ${trade.symbol} to position manager`);
    return true;
  }
  
  // Check if we have an active position for a symbol
  hasActivePosition(symbol) {
    return !!this.activePositions[symbol];
  }
  
  // Get number of active positions
  getActivePositionsCount() {
    return Object.keys(this.activePositions).length;
  }
  
  // Get all active positions
  getAllActivePositions() {
    return Object.values(this.activePositions);
  }
  
  // Check positions for completion or changes
  async checkPositions() {
    const completedPositions = [];
    
    for (const symbol in this.activePositions) {
      try {
        // Get position information from Bybit
        const positionInfo = await this.api.getPosition(symbol);
        
        // If position info is null or size is 0, the position is closed
        if (!positionInfo || parseFloat(positionInfo.size) === 0) {
          const position = this.activePositions[symbol];
          
          try {
            // Get latest ticker to determine close price
            const ticker = await this.api.getTicker(symbol);
            const exitPrice = parseFloat(ticker.lastPrice);
            const entryPrice = position.entryPrice;
            
            // Calculate profit/loss
            let pnl;
            if (position.side === 'long') {
              pnl = (exitPrice - entryPrice) / entryPrice;
            } else {
              pnl = (entryPrice - exitPrice) / entryPrice;
            }
            
            // Record completed trade
            const completedTrade = {
              ...position,
              exitPrice,
              pnl,
              success: pnl > 0,
              closeTime: Date.now()
            };
            
            completedPositions.push(completedTrade);
            
            // Remove from active positions
            delete this.activePositions[symbol];
            
            logger.info(`Position closed for ${symbol}. P&L: ${(pnl * 100).toFixed(2)}%`);
          } catch (error) {
            logger.error(`Error processing completed position for ${symbol}: ${error.message}`);
            // Still remove from active positions to prevent hanging
            delete this.activePositions[symbol];
          }
        } else {
          // Position is still active, check if we need to adjust TP/SL
          await this.checkTrailingStopLoss(symbol, positionInfo);
        }
      } catch (error) {
        logger.error(`Error checking position for ${symbol}: ${error.message}`);
      }
    }
    
    return completedPositions;
  }
  
  // Implement trailing stop loss based on profit
  async checkTrailingStopLoss(symbol, positionInfo) {
    if (!this.config.trailingStop || !this.config.trailingStop.enabled) {
      return;
    }
    
    try {
      const position = this.activePositions[symbol];
      if (!position) return;
      
      const entryPrice = parseFloat(position.entryPrice);
      const currentPrice = parseFloat(positionInfo.markPrice);
      
      // Calculate current profit percentage
      let profitPercent;
      if (position.side === 'long') {
        profitPercent = (currentPrice - entryPrice) / entryPrice;
      } else {
        profitPercent = (entryPrice - currentPrice) / entryPrice;
      }
      
      // Check if we've reached the activation threshold
      if (profitPercent >= this.config.trailingStop.activationThreshold) {
        // Calculate new stop loss level
        let newStopLoss;
        
        if (position.side === 'long') {
          // For long positions, calculate a trailing stop below current price
          const trailDistance = currentPrice * this.config.trailingStop.trailPercent;
          newStopLoss = currentPrice - trailDistance;
          
          // Only update if new stop loss is higher than current stop loss
          if (newStopLoss > position.stopLossPrice) {
            logger.info(`Updating trailing stop loss for ${symbol} from ${position.stopLossPrice.toFixed(4)} to ${newStopLoss.toFixed(4)}`);
            
            // Update stop loss order
            await this.api.cancelOrder(symbol, position.slOrderId);
            
            const slResult = await this.api.placeConditionalOrder(
              symbol,
              'Sell',
              'Market',
              position.quantity.toFixed(6),
              newStopLoss.toFixed(4),
              null,
              true
            );
            
            // Update position object
            position.slOrderId = slResult.orderId;
            position.stopLossPrice = newStopLoss;
          }
        } else {
          // For short positions, calculate a trailing stop above current price
          const trailDistance = currentPrice * this.config.trailingStop.trailPercent;
          newStopLoss = currentPrice + trailDistance;
          
          // Only update if new stop loss is lower than current stop loss
          if (newStopLoss < position.stopLossPrice) {
            logger.info(`Updating trailing stop loss for ${symbol} from ${position.stopLossPrice.toFixed(4)} to ${newStopLoss.toFixed(4)}`);
            
            // Update stop loss order
            await this.api.cancelOrder(symbol, position.slOrderId);
            
            const slResult = await this.api.placeConditionalOrder(
              symbol,
              'Buy',
              'Market',
              position.quantity.toFixed(6),
              newStopLoss.toFixed(4),
              null,
              true
            );
            
            // Update position object
            position.slOrderId = slResult.orderId;
            position.stopLossPrice = newStopLoss;
          }
        }
      }
    } catch (error) {
      logger.error(`Error updating trailing stop loss for ${symbol}: ${error.message}`);
    }
  }
  
  // Check if a position should be manually closed based on indicators
  async checkPositionSignals(symbol, indicators) {
    try {
      if (!this.activePositions[symbol]) return false;
      
      const position = this.activePositions[symbol];
      const currentIndex = indicators.closes.length - 1;
      
      // Exit signals for long positions
      if (position.side === 'long') {
        // Example: Exit long if MACD crosses below signal line
        const macdCrossBelowSignal = 
          indicators.macd.macdLine[currentIndex - 1] >= indicators.macd.signalLine[currentIndex - 1] && 
          indicators.macd.macdLine[currentIndex] < indicators.macd.signalLine[currentIndex];
        
        // Example: Exit long if RSI moves above 70 (overbought)
        const rsiOverbought = indicators.rsi[currentIndex] > 70;
        
        if (macdCrossBelowSignal || rsiOverbought) {
          logger.info(`Exit signal detected for long position on ${symbol}`);
          return true;
        }
      } 
      // Exit signals for short positions
      else if (position.side === 'short') {
        // Example: Exit short if MACD crosses above signal line
        const macdCrossAboveSignal = 
          indicators.macd.macdLine[currentIndex - 1] <= indicators.macd.signalLine[currentIndex - 1] && 
          indicators.macd.macdLine[currentIndex] > indicators.macd.signalLine[currentIndex];
        
        // Example: Exit short if RSI moves below 30 (oversold)
        const rsiOversold = indicators.rsi[currentIndex] < 30;
        
        if (macdCrossAboveSignal || rsiOversold) {
          logger.info(`Exit signal detected for short position on ${symbol}`);
          return true;
        }
      }
      
      return false;
    } catch (error) {
      logger.error(`Error checking position signals for ${symbol}: ${error.message}`);
      return false;
    }
  }
  
  // Use partial take profits based on position profit
  async checkPartialTakeProfits(symbol, positionInfo) {
    if (!this.config.partialTakeProfit || !this.config.partialTakeProfit.enabled) {
      return;
    }
    
    try {
      const position = this.activePositions[symbol];
      if (!position || position.partialTakeProfitExecuted) return;
      
      const entryPrice = parseFloat(position.entryPrice);
      const currentPrice = parseFloat(positionInfo.markPrice);
      
      // Calculate current profit percentage
      let profitPercent;
      if (position.side === 'long') {
        profitPercent = (currentPrice - entryPrice) / entryPrice;
      } else {
        profitPercent = (entryPrice - currentPrice) / entryPrice;
      }
      
      // Check if we've reached the partial take profit level
      if (profitPercent >= this.config.partialTakeProfit.targetPercent) {
        logger.info(`Taking partial profit for ${symbol} at ${(profitPercent * 100).toFixed(2)}% profit`);
        
        // Determine how much of the position to close
        const percentToClose = this.config.partialTakeProfit.closePercent || 0.5; // default 50%
        
        // Calculate quantity to close
        const qtyToClose = position.quantity * percentToClose;
        
        // Place market order to take partial profit
        const side = position.side === 'long' ? 'Sell' : 'Buy';
        await this.api.placeOrder(
          symbol,
          side,
          'Market',
          qtyToClose.toFixed(6),
          null,
          true
        );
        
        // Update remaining position size
        const remainingQty = position.quantity - qtyToClose;
        position.quantity = remainingQty;
        
        // Mark partial take profit as executed
        position.partialTakeProfitExecuted = true;
        
        // Update TP and SL orders with new quantity
        await this.api.cancelOrder(symbol, position.tpOrderId);
        await this.api.cancelOrder(symbol, position.slOrderId);
        
        const tpResult = await this.api.placeOrder(
          symbol,
          side,
          'Limit',
          remainingQty.toFixed(6),
          position.takeProfitPrice.toFixed(4),
          true
        );
        
        const slResult = await this.api.placeConditionalOrder(
          symbol,
          side,
          'Market',
          remainingQty.toFixed(6),
          position.stopLossPrice.toFixed(4),
          null,
          true
        );
        
        position.tpOrderId = tpResult.orderId;
        position.slOrderId = slResult.orderId;
        
        logger.info(`Partial take profit executed for ${symbol}, remaining quantity: ${remainingQty.toFixed(6)}`);
      }
    } catch (error) {
      logger.error(`Error executing partial take profit for ${symbol}: ${error.message}`);
    }
  }
}

module.exports = PositionManager;