// Data Preparation for ML Model
const tf = require('@tensorflow/tfjs-node');
const logger = require('../utils/logger');

class DataPrep {
  constructor() {
    // Feature normalization constants
    this.normalizationParams = {
      emaRatio: { min: 0.9, max: 1.1 },
      rsi: { min: 0, max: 100 },
      macd: { min: -0.01, max: 0.01 },
      histogram: { min: -0.005, max: 0.005 },
      bbandsPosition: { min: 0, max: 1 },
      vwapDistance: { min: -0.05, max: 0.05 },
      volume: { min: 0, max: 3 }, // normalized to average
      orderbookImbalance: { min: 0.1, max: 10 }
    };
  }
  
  // Prepare training data from historical trades
  prepareTrainingData(trades) {
    try {
      logger.debug(`Preparing training data from ${trades.length} trades`);
      
      // Filter trades with indicator data
      const validTrades = trades.filter(trade => trade.indicators);
      
      if (validTrades.length < 10) {
        logger.warn('Not enough valid trades with indicator data for training');
        return null;
      }
      
      // Extract features and labels
      const features = [];
      const labels = [];
      
      for (const trade of validTrades) {
        const tradeFeatures = this.extractFeaturesFromTrade(trade);
        if (tradeFeatures) {
          features.push(tradeFeatures);
          labels.push(trade.success ? 1 : 0);
        }
      }
      
      if (features.length === 0) {
        logger.warn('No valid features extracted from trades');
        return null;
      }
      
      // Convert to tensors
      return {
        features: tf.tensor2d(features),
        labels: tf.tensor1d(labels)
      };
      
    } catch (error) {
      logger.error(`Error preparing training data: ${error.message}`);
      return null;
    }
  }
  
  // Extract features from a single trade
  extractFeaturesFromTrade(trade) {
    try {
      const ind = trade.indicators;
      if (!ind) return null;
      
      // Basic indicator features
      const features = [
        // EMA ratio
        this.normalizeValue(ind.ema9 / ind.ema21, this.normalizationParams.emaRatio),
        
        // RSI (already 0-100)
        this.normalizeValue(ind.rsi, this.normalizationParams.rsi),
        
        // MACD value
        this.normalizeValue(ind.macd, this.normalizationParams.macd),
        
        // MACD histogram
        this.normalizeValue(ind.histogram, this.normalizationParams.histogram),
        
        // Position in Bollinger Bands (0 = lower band, 1 = upper band)
        this.calculateBBandsPosition(trade.entryPrice, ind.upperBand, ind.lowerBand),
        
        // Distance from VWAP (as percentage)
        ind.vwap ? this.normalizeValue((trade.entryPrice - ind.vwap) / ind.vwap, this.normalizationParams.vwapDistance) : 0,
      ];
      
      // Add orderbook features if available
      if (ind.orderbook) {
        features.push(
          // Orderbook imbalance ratio
          this.normalizeValue(ind.orderbook.imbalanceRatio, this.normalizationParams.orderbookImbalance),
          
          // Significant support/resistance nearby (binary)
          ind.orderbook.nearSupport ? 1 : 0,
          ind.orderbook.nearResistance ? 1 : 0
        );
      } else {
        // Add placeholder values
        features.push(1, 0, 0); // neutral imbalance, no support/resistance
      }
      
      // Add trade direction as feature
      features.push(trade.side === 'long' ? 1 : 0);
      
      return features;
    } catch (error) {
      logger.error(`Error extracting features from trade: ${error.message}`);
      return null;
    }
  }
  
  // Prepare features from current indicators for prediction
  prepareFeatures(indicators) {
    try {
      const currentIndex = indicators.closes.length - 1;
      
      // Calculate BB position
      const currentPrice = indicators.closes[currentIndex];
      const bbPosition = this.calculateBBandsPosition(
        currentPrice,
        indicators.bbands.upper[currentIndex],
        indicators.bbands.lower[currentIndex]
      );
      
      // Calculate VWAP distance
      let vwapDistance = 0;
      if (indicators.vwap && indicators.vwap.vwap && indicators.vwap.vwap[currentIndex]) {
        vwapDistance = this.normalizeValue(
          (currentPrice - indicators.vwap.vwap[currentIndex]) / indicators.vwap.vwap[currentIndex],
          this.normalizationParams.vwapDistance
        );
      }
      
      // Prepare feature array
      const features = [
        // EMA ratio
        this.normalizeValue(
          indicators.ema9[currentIndex] / indicators.ema21[currentIndex],
          this.normalizationParams.emaRatio
        ),
        
        // RSI
        this.normalizeValue(indicators.rsi[currentIndex], this.normalizationParams.rsi),
        
        // MACD
        this.normalizeValue(indicators.macd.macdLine[currentIndex], this.normalizationParams.macd),
        
        // MACD histogram
        this.normalizeValue(indicators.macd.histogram[currentIndex], this.normalizationParams.histogram),
        
        // Bollinger Bands position
        bbPosition,
        
        // VWAP distance
        vwapDistance
      ];
      
      // Add orderbook features if available
      if (indicators.orderbook) {
        features.push(
          // Orderbook imbalance ratio
          this.normalizeValue(indicators.orderbook.imbalanceRatio, this.normalizationParams.orderbookImbalance),
          
          // Near support/resistance (binary)
          indicators.orderbook.nearSupport ? 1 : 0,
          indicators.orderbook.nearResistance ? 1 : 0
        );
      } else {
        // Add placeholder values
        features.push(1, 0, 0);
      }
      
      // Add implied direction based on indicators
      const impliedDirection = indicators.ema9[currentIndex] > indicators.ema21[currentIndex] ? 1 : 0;
      features.push(impliedDirection);
      
      return features;
    } catch (error) {
      logger.error(`Error preparing prediction features: ${error.message}`);
      return null;
    }
  }
  
  // Normalize a value to 0-1 range
  normalizeValue(value, params) {
    if (value === null || value === undefined || isNaN(value)) {
      return 0.5; // Default to middle value for missing data
    }
    
    // Clamp to min-max range
    const clampedValue = Math.max(Math.min(value, params.max), params.min);
    
    // Normalize to 0-1
    return (clampedValue - params.min) / (params.max - params.min);
  }
  
  // Calculate position within Bollinger Bands (0 = lower, 0.5 = middle, 1 = upper)
  calculateBBandsPosition(price, upperBand, lowerBand) {
    try {
      if (!price || !upperBand || !lowerBand) return 0.5;
      
      const range = upperBand - lowerBand;
      if (range <= 0) return 0.5;
      
      const position = (price - lowerBand) / range;
      return Math.max(0, Math.min(1, position)); // Clamp to 0-1
    } catch (error) {
      return 0.5;
    }
  }
}

module.exports = DataPrep;