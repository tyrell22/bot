// ML Model for Trade Prediction
const tf = require('@tensorflow/tfjs-node');
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');
const DataPrep = require('./dataPrep');

class MLModel {
  constructor(config, storage) {
    this.config = config;
    this.storage = storage;
    this.model = null;
    this.modelPath = path.join(process.cwd(), config.modelPath || './models', 'scalping_model');
    this.dataPrep = new DataPrep();
    
    // Create necessary directories
    this.createDirectories();
    
    // Load existing model or create a new one
    this.loadModel();
  }
  
  // Create necessary directories
  createDirectories() {
    const modelDir = path.dirname(this.modelPath);
    if (!fs.existsSync(modelDir)) {
      fs.mkdirSync(modelDir, { recursive: true });
      logger.info(`Created directory for ML models: ${modelDir}`);
    }
  }
  
  // Load existing model or create a new one
  async loadModel() {
    try {
      if (fs.existsSync(`${this.modelPath}/model.json`)) {
        logger.info('Loading saved ML model...');
        this.model = await tf.loadLayersModel(`file://${this.modelPath}/model.json`);
        logger.info('ML model loaded successfully');
      } else {
        logger.info('No saved model found, will create new model on first training');
      }
    } catch (error) {
      logger.error(`Error loading ML model: ${error.message}`);
      logger.info('Will create new model on first training');
    }
  }
  
  // Save model to disk
  async saveModel() {
    if (!this.model) return;
    
    try {
      await this.model.save(`file://${this.modelPath}`);
      logger.info(`ML model saved to ${this.modelPath}`);
    } catch (error) {
      logger.error(`Error saving ML model: ${error.message}`);
    }
  }
  
  // Train model on historical trade data
  async trainModel() {
    try {
      // Get historical trades from storage
      const trades = this.storage.loadTrades();
      
      if (!trades || trades.length < 20) {
        logger.info(`Not enough trade data for training (${trades?.length || 0} trades)`);
        return;
      }
      
      logger.info(`Training ML model with ${trades.length} historical trades`);
      
      // Prepare training data
      const trainingData = this.dataPrep.prepareTrainingData(trades);
      
      if (!trainingData || !trainingData.features || !trainingData.labels) {
        logger.error('Failed to prepare training data');
        return;
      }
      
      // Create model if it doesn't exist
      if (!this.model) {
        this.createModel(trainingData.features.shape[1]);
      }
      
      // Train model
      logger.info('Starting model training...');
      await this.model.fit(trainingData.features, trainingData.labels, {
        epochs: 50,
        batchSize: 16,
        shuffle: true,
        validationSplit: 0.2,
        callbacks: {
          onEpochEnd: (epoch, logs) => {
            if (epoch % 10 === 0) {
              logger.debug(`Epoch ${epoch + 1}: loss = ${logs.loss.toFixed(4)}, accuracy = ${logs.acc.toFixed(4)}`);
            }
          }
        }
      });
      
      // Save model
      logger.info('Model training complete, saving model...');
      await this.saveModel();
      
    } catch (error) {
      logger.error(`Error training ML model: ${error.message}`);
    }
  }
  
  // Create a new model
  createModel(inputFeatures) {
    logger.info(`Creating new ML model with ${inputFeatures} input features`);
    
    this.model = tf.sequential();
    
    // Add layers
    this.model.add(tf.layers.dense({
      units: 32,
      activation: 'relu',
      inputShape: [inputFeatures]
    }));
    
    // Add dropout to prevent overfitting
    this.model.add(tf.layers.dropout({ rate: 0.2 }));
    
    this.model.add(tf.layers.dense({
      units: 16,
      activation: 'relu'
    }));
    
    this.model.add(tf.layers.dense({
      units: 8,
      activation: 'relu'
    }));
    
    this.model.add(tf.layers.dense({
      units: 1,
      activation: 'sigmoid'
    }));
    
    // Compile model
    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'binaryCrossentropy',
      metrics: ['accuracy']
    });
    
    logger.info('Neural network model created');
  }
  
  // Predict success probability for a potential trade
  async predictTrade(indicators) {
    if (!this.model) {
      logger.debug('ML model not ready, skipping prediction');
      return null;
    }
    
    try {
      // Prepare feature array from indicators
      const features = this.dataPrep.prepareFeatures(indicators);
      
      if (!features) {
        logger.error('Failed to prepare features for prediction');
        return null;
      }
      
      // Create tensor
      const featureTensor = tf.tensor2d([features]);
      
      // Make prediction
      const prediction = this.model.predict(featureTensor);
      const confidence = prediction.dataSync()[0];
      
      // Determine direction based on indicators
      const direction = this.determineTradeDirection(indicators);
      
      // Clean up tensors
      featureTensor.dispose();
      prediction.dispose();
      
      logger.debug(`ML prediction for potential trade: ${direction} with confidence ${confidence.toFixed(4)}`);
      
      return {
        direction,
        confidence
      };
    } catch (error) {
      logger.error(`Error making ML prediction: ${error.message}`);
      return null;
    }
  }
  
  // Determine suggested trade direction based on indicators
  determineTradeDirection(indicators) {
    try {
      const currentIndex = indicators.closes.length - 1;
      
      // Use multiple indicators to determine direction
      let longSignals = 0;
      let shortSignals = 0;
      
      // EMA signals
      if (indicators.ema9[currentIndex] > indicators.ema21[currentIndex]) {
        longSignals++;
      } else {
        shortSignals++;
      }
      
      // RSI signals
      if (indicators.rsi[currentIndex] < 40) {
        longSignals++; // Potential oversold
      } else if (indicators.rsi[currentIndex] > 60) {
        shortSignals++; // Potential overbought
      }
      
      // MACD signals
      if (indicators.macd.histogram[currentIndex] > 0) {
        longSignals++;
      } else {
        shortSignals++;
      }
      
      // VWAP signals
      if (indicators.vwapAnalysis && indicators.vwapAnalysis.position === 'below') {
        longSignals++;
      } else if (indicators.vwapAnalysis && indicators.vwapAnalysis.position === 'above') {
        shortSignals++;
      }
      
      // Return direction with most signals
      return longSignals >= shortSignals ? 'long' : 'short';
    } catch (error) {
      logger.error(`Error determining trade direction: ${error.message}`);
      return 'neutral';
    }
  }
  
  // Analyze trade results to improve future predictions
  analyzeTradeResults(completedTrades) {
    if (!completedTrades || completedTrades.length === 0) return;
    
    try {
      // Calculate win rate by trade type
      const longTrades = completedTrades.filter(t => t.side === 'long');
      const shortTrades = completedTrades.filter(t => t.side === 'short');
      
      const longWins = longTrades.filter(t => t.success).length;
      const shortWins = shortTrades.filter(t => t.success).length;
      
      const longWinRate = longTrades.length > 0 ? longWins / longTrades.length : 0;
      const shortWinRate = shortTrades.length > 0 ? shortWins / shortTrades.length : 0;
      
      logger.info('Trade Analysis Results:');
      logger.info(`Long trades: ${longTrades.length} with ${(longWinRate * 100).toFixed(2)}% win rate`);
      logger.info(`Short trades: ${shortTrades.length} with ${(shortWinRate * 100).toFixed(2)}% win rate`);
      
      // Analyze specific indicator conditions
      this.analyzeIndicatorEffectiveness(completedTrades);
      
    } catch (error) {
      logger.error(`Error analyzing trade results: ${error.message}`);
    }
  }
  
  // Analyze which indicators were most effective
  analyzeIndicatorEffectiveness(trades) {
    try {
      // Define indicators to analyze
      const indicators = [
        { name: 'RSI < 30', filter: t => t.indicators && t.indicators.rsi < 30 },
        { name: 'RSI > 70', filter: t => t.indicators && t.indicators.rsi > 70 },
        { name: 'EMA9 > EMA21', filter: t => t.indicators && t.indicators.ema9 > t.indicators.ema21 },
        { name: 'MACD > Signal', filter: t => t.indicators && t.indicators.macd > t.indicators.signal },
        { name: 'Near BB Lower', filter: t => t.indicators && Math.abs(t.entryPrice - t.indicators.lowerBand) / t.entryPrice < 0.01 },
        { name: 'Near BB Upper', filter: t => t.indicators && Math.abs(t.entryPrice - t.indicators.upperBand) / t.entryPrice < 0.01 },
      ];
      
      logger.info('Indicator Effectiveness:');
      
      for (const indicator of indicators) {
        const matchingTrades = trades.filter(indicator.filter);
        if (matchingTrades.length === 0) continue;
        
        const wins = matchingTrades.filter(t => t.success).length;
        const winRate = wins / matchingTrades.length;
        
        logger.info(`${indicator.name}: ${matchingTrades.length} trades with ${(winRate * 100).toFixed(2)}% win rate`);
      }
    } catch (error) {
      logger.error(`Error analyzing indicator effectiveness: ${error.message}`);
    }
  }
}

module.exports = MLModel;