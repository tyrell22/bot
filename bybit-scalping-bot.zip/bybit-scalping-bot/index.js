// Bybit Scalping Bot - Entry Point
const fs = require('fs');
const path = require('path');
const ScalpingBot = require('./src/bot');
const logger = require('./src/utils/logger');

// Load configuration
let config;
const configDir = path.join(__dirname, 'config');
const configPath = path.join(configDir, 'default.json');

// Ensure config directory exists
if (!fs.existsSync(configDir)) {
  fs.mkdirSync(configDir, { recursive: true });
}

// Load or create configuration
if (fs.existsSync(configPath)) {
  try {
    const configData = fs.readFileSync(configPath, 'utf8');
    config = JSON.parse(configData);
    logger.info('Loaded configuration from config/default.json');
  } catch (error) {
    logger.error(`Error loading configuration: ${error.message}`);
    process.exit(1);
  }
} else {
  // Create a default configuration file
  config = {
    apiKey: 'YOUR_API_KEY',
    apiSecret: 'YOUR_API_SECRET',
    symbols: ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'ADAUSDT'],
    maxPositions: 3,
    positionSize: 0.1, // 10% of available balance per trade
    leverage: 10,
    profitTarget: 0.03, // 3%
    stopLoss: 0.04, // 4%
    logging: {
      level: 'info', // debug, info, warn, error
      file: 'scalping-bot.log'
    },
    indicators: {
      ema: {
        short: 9,
        long: 21
      },
      rsi: {
        period: 14,
        overbought: 70,
        oversold: 30
      },
      macd: {
        fast: 12,
        slow: 26,
        signal: 9
      },
      bbands: {
        period: 20,
        stdDev: 2
      },
      vwap: {
        period: 24 // hours
      },
      orderbook: {
        depth: 10, // levels to analyze
        imbalanceThreshold: 2 // ratio indicating significant imbalance
      }
    },
    ml: {
      enabled: true,
      modelPath: './models',
      trainInterval: 10 // retrain after this many trades
    }
  };
  
  try {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    logger.info('Created default configuration file config/default.json');
    logger.info('Please edit the file to add your API credentials before running the bot');
    process.exit(0);
  } catch (error) {
    logger.error(`Error creating configuration file: ${error.message}`);
    process.exit(1);
  }
}

// Check for required configuration
if (config.apiKey === 'YOUR_API_KEY' || config.apiSecret === 'YOUR_API_SECRET') {
  logger.error('Please update the configuration file with your Bybit API credentials');
  process.exit(1);
}

// Create and start the bot
const bot = new ScalpingBot(config);

// Handle process termination
process.on('SIGINT', async () => {
  logger.info('\nGracefully shutting down...');
  
  // Stop the bot
  await bot.stop();
  
  // Log performance statistics
  const stats = bot.getPerformanceStats();
  logger.info('\nPerformance Statistics:');
  logger.info(`Total Trades: ${stats.totalTrades}`);
  logger.info(`Win Rate: ${stats.winRate}%`);
  logger.info(`Average Profit: ${stats.avgProfit}%`);
  logger.info(`Total Profit: ${stats.totalProfit}%`);
  logger.info(`Best Trade: ${stats.bestTrade}%`);
  logger.info(`Worst Trade: ${stats.worstTrade}%`);
  
  logger.info('\nShutdown complete');
  process.exit(0);
});

// Start the bot
bot.start();